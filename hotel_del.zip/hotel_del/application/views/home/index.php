<!DOCTYPE html>
<html lang="en">
<head>
        <style>
        .space{
        text-align:"center";
                }
        </style>
</head>
<body>

<div class="container" >

        <h1 class="space" >Selamat Datang di Hotel Del</h1>
        <img class="space"  src="img/menu/hotell.png" width="1000px" height="500px">
        
        
</div>

        
</body>
</html>


